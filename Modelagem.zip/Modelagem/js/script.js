// script.js

var formNoticia = document.getElementById('form-noticia');
var noticiasContainer = document.getElementById('noticias-container'); // Referência ao container das notícias
var noticias = []; // Array para armazenar as notícias

formNoticia.addEventListener('submit', adicionarNoticia);

// Verificar se há notícias armazenadas no localStorage ao carregar a página
window.addEventListener('load', function() {
  if (localStorage.getItem('noticias')) {
    noticias = JSON.parse(localStorage.getItem('noticias'));
    exibirNoticias();
  }
});

function adicionarNoticia(event) {
  event.preventDefault();
  
  var titulo = document.getElementById('titulo').value;
  var conteudo = document.getElementById('conteudo').value;
  var autor = document.getElementById('autor').value;
  var dataAtual = new Date(); // Obter a data atual
  
  var noticia = {
    id: Date.now(), // ID único para cada notícia
    titulo: titulo,
    conteudo: conteudo,
    autor: autor,
    data: formatarData(dataAtual)
  };
  
  noticias.push(noticia); // Adicionar a notícia ao array
  
  localStorage.setItem('noticias', JSON.stringify(noticias)); // Armazenar as notícias no localStorage
  
  exibirNoticias(); // Exibir as notícias atualizadas
  
  formNoticia.reset();
}

// Função para formatar a data no formato "DD/MM/AAAA"
function formatarData(data) {
  var dia = formatarNumero(data.getDate());
  var mes = formatarNumero(data.getMonth() + 1);
  var ano = data.getFullYear();
  
  return dia + '/' + mes + '/' + ano;
}

// Função auxiliar para formatar números menores que 10 com um zero à esquerda
function formatarNumero(numero) {
  return numero < 10 ? '0' + numero : numero;
}

// Função para exibir as notícias
function exibirNoticias() {
  noticiasContainer.innerHTML = ''; // Limpar o container
  
  for (var i = 0; i < noticias.length; i++) {
    var noticia = noticias[i];
    
    var article = document.createElement('article');
    var h3 = document.createElement('h3');
    var pConteudo = document.createElement('p');
    var pAutor = document.createElement('p');
    var pData = document.createElement('p');
    
    h3.textContent = noticia.titulo;
    pConteudo.textContent = noticia.conteudo;
    pAutor.textContent = 'Autor: ' + noticia.autor;
    pData.textContent = 'Data: ' + noticia.data;
    
    var btnRemover = document.createElement('button');
    btnRemover.textContent = 'Remover';
    
    btnRemover.addEventListener('click', criarEventoRemover(noticia.id)); // Adicionar evento de clique ao botão de remoção
    
    article.appendChild(h3);
    article.appendChild(pConteudo);
    article.appendChild(pAutor);
    article.appendChild(pData);
    article.appendChild(btnRemover);
    
    noticiasContainer.appendChild(article);
  }
}

// Função auxiliar para criar o evento de remoção
function criarEventoRemover(noticiaId) {
  return function() {
    removerNoticia(noticiaId);
  };
}

// Função para remover a notícia
function removerNoticia(noticiaId) {
  noticias = noticias.filter(function(noticia) {
    return noticia.id !== noticiaId;
  });
  
  localStorage.setItem('noticias', JSON.stringify(noticias)); // Atualizar as notícias no localStorage
  exibirNoticias(); // Exibir as notícias atualizadas
}
